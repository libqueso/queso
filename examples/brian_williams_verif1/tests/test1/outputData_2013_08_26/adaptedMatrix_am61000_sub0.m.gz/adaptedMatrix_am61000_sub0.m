mat_am61000_sub0 = zeros(1,1);
mat_am61000_sub0 = [3.64121e-06 
];
