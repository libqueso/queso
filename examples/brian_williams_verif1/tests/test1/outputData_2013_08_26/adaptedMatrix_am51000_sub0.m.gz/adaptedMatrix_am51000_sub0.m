mat_am51000_sub0 = zeros(1,1);
mat_am51000_sub0 = [3.67597e-06 
];
