mat_am121000_sub0 = zeros(1,1);
mat_am121000_sub0 = [3.60556e-06 
];
