mat_am71000_sub0 = zeros(1,1);
mat_am71000_sub0 = [0.000268675 
];
