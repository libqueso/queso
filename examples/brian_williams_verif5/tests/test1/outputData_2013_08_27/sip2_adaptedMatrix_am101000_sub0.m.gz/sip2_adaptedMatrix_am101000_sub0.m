mat_am101000_sub0 = zeros(1,1);
mat_am101000_sub0 = [0.0245822 
];
