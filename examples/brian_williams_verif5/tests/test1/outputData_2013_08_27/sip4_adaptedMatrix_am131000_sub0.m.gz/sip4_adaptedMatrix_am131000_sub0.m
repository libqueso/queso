mat_am131000_sub0 = zeros(1,1);
mat_am131000_sub0 = [0.000517761 
];
