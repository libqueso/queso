mat_am41000_sub0 = zeros(1,1);
mat_am41000_sub0 = [0.00254758 
];
