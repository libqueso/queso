mat_am1000_sub0 = zeros(1,1);
mat_am1000_sub0 = [0.00157575 
];
