mat_am51000_sub0 = zeros(1,1);
mat_am51000_sub0 = [0.00053808 
];
